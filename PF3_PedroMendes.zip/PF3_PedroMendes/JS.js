function  calcular ( )
{

    const  nome  =  documento . getElementById ( 'Nome' ) . valor
    const  mensal  =  Number ( document . getElementById ( 'ValorMensal' ) . value )
    const  tjuros  =  Number ( document . getElementById ( 'Juros' ) . value )
    const  meses  =  Number ( document . getElementById ( 'Parcelas' ) . value )

    const  Juros  =  tjuros / 100

   var  res  =  documento . getElementById ( "resultado" )




    deixe  (p)  =  ( mensal * ( ( 1 + Juros ) ** meses - 1 ) / Juros ) . toFixed ( 2 )

}